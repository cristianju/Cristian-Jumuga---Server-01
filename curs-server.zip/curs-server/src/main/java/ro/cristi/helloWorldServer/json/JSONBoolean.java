package ro.cristi.helloWorldServer.json;

public class JSONBoolean implements JSONValue {
	private final boolean value;

	public JSONBoolean(boolean value) {
		this.value = value;
	}
	
	@Override
	public String toString() {
		if(this.value) {
			return "true";
		}
		return "false";
	}
	
	

}
