package ro.cristi.helloWorldServer;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import ro.cristi.helloWorldServer.files.FileHandler;
import ro.cristi.helloWorldServer.files.PeopleHandler;
import ro.cristi.helloWorldServer.json.JSONHandler;
import ro.cristi.helloWorldServer.model.Block;
import ro.cristi.helloWorldServer.model.Question;
import ro.cristi.helloWorldServer.questions.CQDataSource;
import ro.cristi.helloWorldServer.questions.JSONQuestionSerializer;
import ro.cristi.helloWorldServer.questions.QuestionDataSource;
import ro.cristi.helloWorldServer.questions.QuestionHandler;
import ro.cristi.helloWorldServer.questions.QuestionListHandler;
import ro.cristi.helloWorldServer.questions.QuestionSerializer;
import ro.cristi.helloWorldServer.questions.YAMLFileQuestionDataSource;
import ro.cristi.helloWorldServer.questions.YAMLSerializer;
import ro.cristi.helloWorldServer.router.Router;
import ro.itschool.server.Server;

public class Main {
	
	private static final String ROOT = "/.*";
	private static final String IMAGES = "/images/.*";
//	private static final String JAVASCRIPT = "/js/\\S*";
//	private static final String CSS = "/css/\\S*";
	private static final String HELLO = "/hello";
	private static final String YAML = "/yaml/\\d+";
	private static final String PEOPLE = "/api/people";

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		
			Router router = new Router();
			
			final QuestionDataSource ds = 
					new YAMLFileQuestionDataSource("resources/questions");
			final QuestionSerializer serializer = new JSONQuestionSerializer();

			router.addRoute(IMAGES, new FileHandler("public"));
			router.addRoute("/favicon.ico", new FileHandler("public/images"));
			router.addRoute(HELLO, new JSONHandler());
			router.addRoute("/api/questions", new QuestionListHandler(ds, serializer));
			router.addRoute("/api/questions/\\d+", new QuestionHandler(ds, serializer));
			router.addRoute(YAML, new QuestionHandler(new CQDataSource(), 
							new YAMLSerializer()));
			router.addRoute(PEOPLE, new PeopleHandler());
			router.addRoute(ROOT, new FileHandler("public"));
			
			
			Integer port;
			
			try {
				port = Integer.parseInt(System.getenv("PORT"));
			} catch (Exception ex) {
				port = 8080;
			}
			
			final Server s = new Server(port, router);
			System.out.println("Started server on port " + port);
			s.start();

	}

}
