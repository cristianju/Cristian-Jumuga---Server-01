package ro.cristi.helloWorldServer.questions;

import java.util.List;

import ro.cristi.helloWorldServer.json.JSONArray;
import ro.cristi.helloWorldServer.json.JSONNumber;
import ro.cristi.helloWorldServer.json.JSONObject;
import ro.cristi.helloWorldServer.json.JSONString;
import ro.cristi.helloWorldServer.model.Block;
import ro.cristi.helloWorldServer.model.Question;

public class JSONQuestionSerializer implements QuestionSerializer {

	public String serialize(Question q) {
		JSONObject json = toJsonValue(q);
		return json.toString();
	}

	private JSONObject toJsonValue(Question q) {
		JSONObject json = new JSONObject();
		json.put("id", new JSONNumber(q.getId()));
		json.put("title", new JSONString(q.getTitle()));
		json.put("author", new JSONString(q.getAuthor()));
		json.put("explanation", new JSONString(q.getExplanation()));
		
		JSONArray blocks = new JSONArray();
		
		for (Block b : q.getBlocks()) {
			if (b.getType().equals("text")) {
				blocks.add(new JSONString(b.getCorrectAnswer()));
			} else {
			
			JSONObject blockJson = new JSONObject();
			blockJson.put("type", new JSONString(b.getType()));
			blockJson.put("correctAnswer", new JSONString(b.getCorrectAnswer()));
			JSONArray optionJson = new JSONArray();
			for (String option : b.getOptions()) {
				optionJson.add(new JSONString(option));
			}
			blockJson.put("options", optionJson);
			blocks.add(blockJson);
			}
		}
		json.put("blocks", blocks);
		return json;
	}

	public String getContentType() {		
		return "application/json";
	}

	public String serializeAll(List<Question> l) {
		JSONArray arr = new JSONArray();
		for(Question q : l) {
			arr.add(toJsonValue(q));
		}
		return arr.toString();
	}
	
//	private JSONValue serializeTextBlock(Block b) {
//		return new JSONString(b.getCorrectAnswer());
//	}

//	private JSONValue serializeChoiceBlock(Block b) {
//		JSONObject block = new JSONObject();
//		block.put("name", b.getName());
//		block.put("type", b.getType());
//		JSONArray options = new JSONArray();
//		for (String option : b.getOptions()) {
//			options.add(option);
//		}
//		block.put("options", options);
//		block.put("correctAnswer", serializeTextBlock(b));
//		return block;
//	}

}
