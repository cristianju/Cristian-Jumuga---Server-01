package ro.cristi.helloWorldServer.model;

import java.util.ArrayList;
import java.util.List;

public class Block {
	private String type;
	private List<String> options;
	private String correctAnswer;
	
	public Block() {
		this.options = new ArrayList<String>();
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	
	public List<String> getOptions() {
		return options;
	}
	
	public void addOptions(String option) {
		this.options.add(option);
	}
	
	public void setCorrectAnswer(String correctAnswer) {
		this.correctAnswer = correctAnswer;
	}
	
	public String getCorrectAnswer() {
		return correctAnswer;
	}
}
