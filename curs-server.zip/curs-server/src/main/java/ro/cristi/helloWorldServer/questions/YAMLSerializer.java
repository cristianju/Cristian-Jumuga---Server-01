package ro.cristi.helloWorldServer.questions;

import java.util.List;

import ro.cristi.helloWorldServer.model.Block;
import ro.cristi.helloWorldServer.model.Question;

public class YAMLSerializer implements QuestionSerializer {

	public String serialize(Question q) {
		String result = "--- \n";
		result += "- title: " + q.getTitle() + "\n";
		result += "  blocks: " + "\n";
		List<Block> blocks = q.getBlocks();
		for (Block b : blocks) {
			result += "  - correctAnswer: " + b.getCorrectAnswer() + "\n";
			result += "  - options:  " + b.getOptions() + "\n";
			result += "  - type: " + b.getType() + "\n";
		}
		
		result += "  author: " + q.getAuthor() + "\n";
		
		int id = q.getId();
		result += "  id: " + id + "\n";
		
		result += "  explanation: " + q.getExplanation();
		
		return result;
	}

	public String getContentType() {
		return "text/plain";
	}

	public String serializeAll(List<Question> l) {
		for (Question q : l) {
			serialize(q);
		}
		return null;
	}

}
