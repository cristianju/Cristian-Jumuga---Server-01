package ro.cristi.helloWorldServer;

import ro.cristi.helloWorldServer.json.JSONHandler;
import ro.itschool.server.Server;

public class Hello2 {

	public static void main(String[] args) {
		JSONHandler req = new JSONHandler();
		Server s = new Server(1337, req);
		s.start();
	}

}
