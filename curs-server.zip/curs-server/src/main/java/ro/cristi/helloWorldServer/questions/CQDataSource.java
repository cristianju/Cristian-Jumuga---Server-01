// ConstantQuestionDataSource

package ro.cristi.helloWorldServer.questions;

import java.util.LinkedList;
import java.util.List;

import ro.cristi.helloWorldServer.model.Block;
import ro.cristi.helloWorldServer.model.Question;

public class CQDataSource implements QuestionDataSource {

	
	public Question getById(int id) {
		Question q = new Question();
		q.setId(id);
		q.setTitle("Hello World");
		q.setAuthor("Jhon Snow");
		q.setExplanation("No explanation needed.");
		
		Block b1 = new Block();
		b1.setType("text");
		b1.setCorrectAnswer("Some text here.");
		q.addBlock(b1);
		
		Block b2 = new Block();
		b2.setType("text");
		b2.setCorrectAnswer("Some other text here.");
		q.addBlock(b2);
		
		return q;
	}

	public List<Question> getAll() {
		List<Question> l = new LinkedList<Question>();
		for(int i = 0; i < 10; i++) {
			l.add(this.getById(i));
		}
		return l;
	}

}
