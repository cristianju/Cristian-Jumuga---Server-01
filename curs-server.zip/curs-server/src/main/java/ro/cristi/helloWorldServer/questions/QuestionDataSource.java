package ro.cristi.helloWorldServer.questions;

import java.util.List;

import ro.cristi.helloWorldServer.model.Question;

public interface QuestionDataSource {
	Question getById(int id);
	List<Question> getAll();
}
