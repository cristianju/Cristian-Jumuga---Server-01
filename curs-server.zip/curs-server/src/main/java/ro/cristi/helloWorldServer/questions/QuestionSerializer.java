package ro.cristi.helloWorldServer.questions;

import java.util.List;

import ro.cristi.helloWorldServer.model.Question;

public interface QuestionSerializer {
	String serialize(Question q);
	String getContentType();
	String serializeAll(List<Question> l);
}
