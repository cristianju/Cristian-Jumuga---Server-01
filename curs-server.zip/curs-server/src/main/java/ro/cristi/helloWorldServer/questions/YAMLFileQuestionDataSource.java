package ro.cristi.helloWorldServer.questions;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import ro.cristi.helloWorldServer.model.Block;
import ro.cristi.helloWorldServer.model.Question;

public class YAMLFileQuestionDataSource implements QuestionDataSource {
	
	private final String folder;
	
	public YAMLFileQuestionDataSource (String folder) {
		this.folder = folder;
	}

	public Question getById(int id) {
		String filePath = this.folder + "/" + id + ".yaml";
		try {
			Question result = parseQuestion(new ObjectMapper(new YAMLFactory()), 
				new File(filePath));
			return result;
		} catch (Exception ex) {
			return null;
		}
	}

	public List<Question> getAll() {
		ObjectMapper m = new ObjectMapper(new YAMLFactory());
		List<Question> result = new ArrayList<Question>();
		File folder = new File(this.folder);
		File[] files = folder.listFiles();
		try {
			for(File f : files) {
				result.add(parseQuestion(m, f));
			}
			return result;
		} catch (Exception ex) {
			ex.printStackTrace();
			return new ArrayList<Question>();
		}
	}
	
	private Question parseQuestion(ObjectMapper mapper, File f) throws JsonParseException, JsonMappingException, IOException {
		TypeReference<Map<String, Object>> type = 
				new TypeReference<Map<String, Object>>() {
		};
		
		Map<String, Object> result = mapper.readValue(f, type);
		
		Question q = new Question();
		
		int id = (Integer) result.get("id");
		q.setId(id);
		
		String title = (String) result.get("title");
		q.setTitle(title);
		
		String explanation = (String) result.get("explanation");
		q.setExplanation(explanation);
		
		List<Object> blocks = (List<Object>) result.get("blocks");
		for (Object o : blocks) {
			if (o instanceof Map) {
				Map<String, Object> blockItem = (Map<String, Object>) o;
				Block b = new Block();
				b.setType(blockItem.get("type").toString());
				b.setCorrectAnswer(blockItem.get("correctAnswer").toString());
				
				List<String> options = (List<String>) blockItem.get("data");
				if(options != null) {
					for (String op : options) {
						b.addOptions(op);
					}
				}
				q.addBlock(b);
			} else {
				Block b = new Block();
				b.setCorrectAnswer(o.toString());
				b.setType("text");
				q.addBlock(b);
			}
		}
		
		return q;
	}

}
