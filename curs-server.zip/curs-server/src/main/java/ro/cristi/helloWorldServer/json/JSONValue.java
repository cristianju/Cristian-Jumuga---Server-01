package ro.cristi.helloWorldServer.json;

public interface JSONValue {

}
