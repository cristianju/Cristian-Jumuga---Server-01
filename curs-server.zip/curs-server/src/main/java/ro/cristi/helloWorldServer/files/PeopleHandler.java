package ro.cristi.helloWorldServer.files;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ro.cristi.helloWorldServer.Person;
import ro.cristi.helloWorldServer.json.JSONArray;
import ro.cristi.helloWorldServer.json.JSONObject;
import ro.cristi.helloWorldServer.json.JSONString;
import ro.itschool.server.Request;
import ro.itschool.server.RequestHandler;
import ro.itschool.server.Response;

public class PeopleHandler implements RequestHandler {
	private PeopleDataSource pds = new PeopleDataSource();

	public Response handle(Request req) {
		Response r = new Response();
		if (req.getMethod().equalsIgnoreCase("POST")) {
			pds.save(deserialize(req));
		} else if (req.getMethod().equalsIgnoreCase("GET")) {
			r.send(serialize(pds.getAllPeople()));
		}
		return r;
	}
	
	private Person deserialize(Request req) {
		ObjectMapper m = new ObjectMapper(new JsonFactory());
		Person p = null;
		try {
			p = m.readValue(req.getBody(), Person.class);
		} catch (Exception e) {
			p = null;
		}
		return p;
	}
	private String serialize(List<Person> l) {
		JSONArray json = new JSONArray();
		
		for (Person person : l) {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("nume", new JSONString(person.getName()));
			jsonObj.put("prenume", new JSONString(person.getFirstName()));
			jsonObj.put("mobile", new JSONString(person.getMobile()));
			json.add(jsonObj);
		}
		String result = json.toString();
		return result;
	}
	

}