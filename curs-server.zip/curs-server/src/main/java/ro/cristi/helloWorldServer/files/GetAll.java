package ro.cristi.helloWorldServer.files;

import java.util.List;

import ro.cristi.helloWorldServer.Person;

public interface GetAll {
	List<Person> getAllPeople();
	void save(Person p);
}
