package ro.cristi.helloWorldServer;

import ro.cristi.helloWorldServer.files.FileHandler;
import ro.cristi.helloWorldServer.json.JSONHandler;
import ro.cristi.helloWorldServer.questions.CQDataSource;
import ro.cristi.helloWorldServer.questions.JSONQuestionSerializer;
import ro.cristi.helloWorldServer.questions.QuestionHandler;
import ro.cristi.helloWorldServer.questions.QuestionListHandler;
import ro.cristi.helloWorldServer.questions.YAMLSerializer;
import ro.cristi.helloWorldServer.router.Router;
import ro.itschool.server.Server;

public class Hello1 {
	private static final String ROOT = "/\\S*";
	private static final String IMAGES = "/images/\\S*";
//	private static final String JAVASCRIPT = "/js/\\S*";
//	private static final String CSS = "/css/\\S*";
	private static final String HELLO = "/hello";
	private static final String YAML = "/yaml/\\d+";
	
	public static void main(String[] args) {
		Router router = new Router();
		
		router.addRoute(IMAGES, new FileHandler("public"));
		router.addRoute(HELLO, new JSONHandler());
		router.addRoute("/questions", 
				new QuestionListHandler(new CQDataSource(), 
						new JSONQuestionSerializer()));
		router.addRoute("/questions/\\d+", 
				new QuestionHandler(new CQDataSource(), 
						new JSONQuestionSerializer()));
		router.addRoute(YAML, 
				new QuestionHandler(new CQDataSource(), 
						new YAMLSerializer()));
		router.addRoute(ROOT, new FileHandler("public"));
		
		Server s = new Server(1337, router);
		s.start();
		
	
//		router.addRoute("/images/\\S*", new FileHandler("public"));
//		router.addRoute("/", new FileHandler("public"));
		
//		obj.put("nume", new JSONString("Boogie"));
//		obj.put("varsta", new JSONNumber(30));
		
//		System.out.println(obj);
	}

}
