package ro.cristi.helloWorldServer.files;

import java.util.LinkedList;
import java.util.List;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.ObjectMapper;

import ro.cristi.helloWorldServer.Person;
import ro.cristi.helloWorldServer.json.JSONArray;
import ro.cristi.helloWorldServer.json.JSONObject;
import ro.cristi.helloWorldServer.json.JSONString;

public class PeopleDataSource implements GetAll {
	
	private List<Person> personsList = new LinkedList<Person>();

	public List<Person> getAllPeople() {	
		return this.personsList;
	}

	public void save(Person p) {
		personsList.add(p);
	}
	
	

	

}
