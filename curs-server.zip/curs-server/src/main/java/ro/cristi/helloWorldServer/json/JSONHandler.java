package ro.cristi.helloWorldServer.json;

import ro.itschool.server.Request;
import ro.itschool.server.RequestHandler;
import ro.itschool.server.Response;

public class JSONHandler implements RequestHandler {
	
	public JSONHandler() {
	}

	public Response handle(Request req) {
		JSONObject result = new JSONObject();
		result.put("hello1", new JSONString("world1"));
		result.put("hello2", new JSONString("world2"));
		
		JSONObject result2 = new JSONObject();
		result2.put("a", new JSONNumber(42));
		
		result.put("hello1", result2);
		
		Response r = new Response();
		r.send(result);
		r.sendHeader("Content-Type", "application/json");
		return r;
	}

}
