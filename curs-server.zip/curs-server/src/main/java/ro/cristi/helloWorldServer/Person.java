package ro.cristi.helloWorldServer;

public class Person {
	private String firstName;
	private String name;
	private String mobile;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String prenume) {
		this.firstName = prenume;
	}
	public String getName() {
		return name;
	}
	public void setName(String nume) {
		this.name = nume;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

}
